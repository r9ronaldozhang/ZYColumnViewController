//
//  ViewController.m
//  OC-ZYColumnViewController
//
//  Created by 张宇 on 2016/10/31.
//  Copyright © 2016年 成都拓尔思. All rights reserved.
//

#import "ViewController.h"
#import "ZYColumnViewController.h"

@interface ViewController ()<ZYColumnViewControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor grayColor];
    
    // 注意，控制器需要有导航控制器支持，直接扔UIViewController没反应不负责哦，封装得没有swift版本好。不过内存方面不会有问题
    // DIY不如swift 不过修改思路一样  在ZYSparesButton里面改 item的样式  自定义其他样式在ZYDefinition.h里面调整。对外的API 比swift多些，详见
    // ZYColumnViewController.h
    // 编译测试版本  XCode 7.3 XCode7.3.1 XCode8.1
    
    // 使用方法：
    NSArray *array = @[@"头条",@"财经",@"体育",@"娱乐圈",@"段子",@"健康",@"图片",@"军事",@"精选",@"国际足球",@"历史",@"跟帖",@"居家"];
    NSArray *spareArray = @[@"房产",@"直播",@"轻松一刻",@"独家",@"社会",@"手机",@"数码",@"酒香",@"美女",@"艺术",@"读书",@"情感",@"论坛",@"博客",@"NBA",@"旅游",@"跑步",@"影视",@"政务",@"本地",@"汽车",@"公开课",@"游戏",@"独家",@"时尚",@"轻松一刻",@"社会",@"漫画"];
    
    // 初始化
    ZYColumnViewController *columnViewVC = [[ZYColumnViewController alloc] initWithColumnNames:array SpareColumnNames:spareArray];
    columnViewVC.fixedCount = 1;
    columnViewVC.delegate = self;
    [self.view insertSubview:columnViewVC.view atIndex:0];
    [self addChildViewController:columnViewVC];
}

#pragma mark - ZYColumnViewController 代理方法
- (void)columnViewDidSelected:(ZYColumnViewController *)columnViewVC AtIndex:(NSInteger)index
{

}

- (void)columnViewDidChanged:(NSMutableArray *)columnNames SpareColumnNamesArray:(NSMutableArray *)spareColumnNames{

}

- (void)columnViewColumnTitleButton:(UIButton *)button DidClickAtIndex:(NSInteger)index {

}


@end
